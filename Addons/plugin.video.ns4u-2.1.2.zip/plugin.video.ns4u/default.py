# -*- coding: utf-8 -*-

"""
    ProSports NS4U Edition XBMC Addon
    Copyright (C) 2016 jsergio

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import urllib,urllib2,re,os,xbmc,xbmcplugin,xbmcgui,xbmcaddon,xbmcvfs,urlparse
from operator import itemgetter

import sys

from resources.lib.modules import client,control
import praw

action              = None
setSetting          = xbmcaddon.Addon().setSetting
getSetting          = xbmcaddon.Addon().getSetting
addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")
addonFullId         = addonName + addonVersion
#addonDesc           = ''
addonIcon           = os.path.join(addonPath,'icon.png')
addonFanart         = os.path.join(addonPath,'fanart.jpg')
logoPath            = os.path.join(addonPath,'resources/art/logos/')
fanartPath          = os.path.join(addonPath,'resources/art/fanart/')
dataPath            = xbmc.translatePath('special://profile/addon_data/%s' % addonId)
tempPath            = xbmc.translatePath('special://temp')
subreddit           = 'ns4u'
username, password  = getSetting("username"), getSetting("password")
userAgent           = '%s addon for Kodi' % subreddit.upper()


class Main:
    def __init__(self):
        global action
        params = {}
        splitparams = sys.argv[2][sys.argv[2].find('?') + 1:].split('&')
        for param in splitparams:
            if len(param) > 0:
                splitparam = param.split('=')
                key = splitparam[0]
                try:    value = splitparam[1].encode("utf-8")
                except: value = splitparam[1]
                params[key] = value

        try:        action = urllib.unquote_plus(params["action"])
        except:     action = None
        try:        url = urllib.unquote_plus(params["url"])
        except:     url = None
        try:        name = urllib.unquote_plus(params["name"])
        except:     name = None
        #try:        title = urllib.unquote_plus(params["title"])
        #except:     title = None
        try:        sport = urllib.unquote_plus(params["sport"])
        except:     sport = None
        try:        comment = urllib.unquote_plus(params["comment"])
        except:     comment = 'true'
        try:        default_quality = urllib.unquote_plus(params["default_quality"])
        except:     default_quality = getSetting('default_quality')


        if username == '' or password == '': self.opensettings()
        if action is None: Root().get()
        elif action == 'browse':
            dialog = xbmcgui.Dialog()
            types = ['NFL', 'NBA', 'NHL', 'MLS', 'UFC', 'EPL', 'MLB', 'WWE', 'NCAAF', 'UEFA Soccer', 'NCAAM', 'CFL', 'BOXING', 'Italian Serie A Soccer', 'NASL', 'REDZONE', 'KICKBOXING', 'TV', 'CRICKET', 'Week', 'GOLF', 'MMA', 'BTN']
            types = sorted(types, key=str.lower)
            selected = dialog.select('Choose a type', types)
            if selected == -1: return
            else: Threads().get(types[selected])
        elif action == 'search':
            query = Index().get_user_input('Search %s' % subreddit.upper(), '')
            if not query: return
            Threads().get(query)
        elif action == subreddit: Threads().get(subreddit)
        elif action == 'sources': Sources().get(url, sport, comment)
        elif action == 'wake': Sources().wake(url, sport, comment)
        elif action == 'play':
            if 'filenurse.com/download/' in url:
                url = Index().download(url)
            elif default_quality == 'false':
                try:
                    headers = ''
                    if '|' in url:
                        url_split = url.split('|')
                        url = url_split[0]
                        headers = '|%s' % url_split[1]
                    url = re.sub(r'[\d]+K/[\d]+_slide\.m3u8', 'master_tablet.m3u8', url)
                    result = client.request(url, timeout='10')
                    if '#EXT-X-STREAM-INF:' in result:
                        bandwidth = [int(i) for i in re.findall(r'^#EXT-X-STREAM-INF:.*?BANDWIDTH=([\d]+)', result, re.MULTILINE)]
                        streams = re.findall(r'^[^#\s].+', result, re.MULTILINE)
                        if '/nhl/' in url and not 'composite' in name.lower():
                            bandwidth.extend([5000000])
                            streams.extend(['5000K/5000_slide.m3u8'])
                        zipped = zip(bandwidth, streams)
                        zipped.sort(key=itemgetter(0), reverse=True)
                        bandwidth, streams = zip(*zipped)
                        bandwidth = ['%sKbps' % int(float(x) / 1000) for x in bandwidth]
                        dialog = xbmcgui.Dialog()
                        selected = dialog.select('Choose your desired bandwidth', bandwidth)
                        if selected == -1: return
                        else:
                            if not streams[selected].startswith("http") and not streams[selected].startswith("rtmp"):
                                new_url = urlparse.urljoin(url, streams[selected])
                                if '?' in url:
                                    query = urlparse.urlsplit(url).query
                                    url = '%s?%s%s' % (new_url, query, headers)
                                else:
                                    url = '%s%s' % (new_url, headers)
                            else:
                                cookies = client.request(url, output='cookie', timeout='10')
                                new_url = streams[selected]
                                if cookies and not 'mediaauth=' in headers.lower():
                                    cookies = urllib.quote_plus(urllib.unquote_plus(cookies))
                                    url = '%s|Cookie=%s' % (new_url, cookies)
                                else: url = '%s%s' % (new_url, headers)
                    else:
                        url += headers
                except:
                    pass
            elif 'anvato.net/' in url:
                try:
                    import requests
                    r = requests.get(url, allow_redirects=False)
                    url = r.headers["Location"]
                except:
                    pass
                    
            if url.startswith('http'):
                if not 'user-agent=' in url.lower():
                    if '|' in url: url = '%s&User-Agent=%s' % (url, client.agent())
                    else: url = '%s|User-Agent=%s' % (url, client.agent())
                if getSetting("set_forwarded") == 'true':
                    forwarded = getSetting("forwarded")
                    if not "x-forwarded-for=" in url.lower():
                        if '|' in url: url = '%s&X-Forwarded-For=%s' % (url, forwarded)
                        else: url = '%s|X-Forwarded-For=%s' % (url, forwarded)
                    else: url = re.sub(r'(?i)x-forwarded-for=\d{0,3}\.\d{0,3}\.\d{0,3}\.\d{0,3}', 'X-Forwarded-For=%s' % forwarded, url)
                
            url = str(url)
            #print ":::url:::", url
            item = xbmcgui.ListItem(path=url)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        else: Sources().get(action, sport, comment)
        
        xbmcplugin.setPluginFanart(int(sys.argv[1]), addonFanart)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
        return
        
    @staticmethod
    def opensettings():
        try:
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.executebuiltin('Addon.OpenSettings(%s)' % addonId)
            xbmc.executebuiltin("XBMC.Container.Update(addons://sources/video/,replace)")
            quit()
        except:
            quit()

class Images:
    def __init__(self):
        self.logo = {'nba': os.path.join(logoPath, 'nba.jpg'),
        'nfl': os.path.join(logoPath, 'nfl.jpg'),
        'mlb': os.path.join(logoPath, 'mlb.jpg'),
        'nhl': os.path.join(logoPath, 'nhl.jpg'),
        'soccer': os.path.join(logoPath, 'soccer.jpg'),
        'mma': os.path.join(logoPath, 'mma.jpg'),
        'boxing': os.path.join(logoPath, 'boxing.jpg'),
        'ncaa': os.path.join(logoPath, 'ncaa.jpg'),
        'cfb': os.path.join(logoPath, 'cfb.jpg'),
        'wwe': os.path.join(logoPath, 'wwe.jpg'),
        'rugby': os.path.join(logoPath, 'rugby.jpg'),
        'secnetwork': os.path.join(logoPath, 'secnetwork.jpg'),
        'espn': os.path.join(logoPath, 'espn.jpg'),
        'clearstreams': os.path.join(logoPath, 'clearstreams.jpg'),
        'pac12': os.path.join(logoPath, 'pac12.jpg'),
        'search': os.path.join(logoPath, 'search.jpg'),
        'default': os.path.join(addonPath, 'icon.png')}
        
        self.fanart = {'nba': os.path.join(fanartPath, 'nba.jpg'),
        'nfl': os.path.join(fanartPath, 'nfl.jpg'),
        'mlb': os.path.join(fanartPath, 'mlb.jpg'),
        'nhl': os.path.join(fanartPath, 'nhl.jpg'),
        'soccer': os.path.join(fanartPath, 'soccer.jpg'),
        'mma': os.path.join(fanartPath, 'mma.jpg'),
        'boxing': os.path.join(fanartPath, 'boxing.jpg'),
        'ncaa': os.path.join(fanartPath, 'ncaa.jpg'),
        'cfb': os.path.join(fanartPath, 'cfb.jpg'),
        'wwe': os.path.join(fanartPath, 'wwe.jpg'),
        'rugby': os.path.join(fanartPath, 'rugby.jpg'),
        'secnetwork': os.path.join(fanartPath, 'secnetwork.jpg'),
        'espn': os.path.join(fanartPath, 'espn.jpg'),
        'clearstreams': os.path.join(addonPath, 'fanart.jpg'),
        'pac12': os.path.join(fanartPath, 'pac12.jpg'),
        'search': os.path.join(addonPath, 'fanart.jpg'),
        'default': os.path.join(addonPath, 'fanart.jpg')}

class Root:
    def __init__(self):
        pass

    @staticmethod
    def get():
        root_list = [{'name': '[COLOR=FF00FF00][ All Games/Events ][/COLOR]', 'sport': 'default', 'action': subreddit},
                    {'name': '[COLOR=FF00FF00][ Browse by type ][/COLOR]', 'sport': 'default', 'action': 'browse'},
                    {'name': '[COLOR=FF00FF00][ MLB Network ][/COLOR]', 'sport': 'mlb', 'action': '48idsl'},
                    {'name': '[COLOR=FF00FF00][ NFL Network ][/COLOR]', 'sport': 'nfl', 'action': '5wqa2k'},
                    {'name': '[COLOR=FF00FF00][ ESPN Channels ][/COLOR]', 'sport': 'espn', 'action': '583v7u'},
                    {'name': '[COLOR=FF00FF00][ SEC Network ][/COLOR]', 'sport': 'secnetwork', 'action': '583vc4'},
                    {'name': '[COLOR=FF00FF00][ WWE Network ][/COLOR]', 'sport': 'wwe', 'action': '4vysxl'},
                    {'name': '[COLOR=FF00FF00][ Clear Streams ][/COLOR]', 'sport': 'clearstreams',
                     'action': 'wiki/clearstreams'},
                    {'name': '[COLOR=FF00FF00][ PAC-12 Channels ][/COLOR]', 'sport': 'pac12', 'action': '3r6jhz'},
                    {'name': '[COLOR=FF00FF00][ BTN Network ][/COLOR]', 'sport': 'default', 'action': '57anj9'},
                    {'name': '[COLOR=FF00FF00][ NBA TV ][/COLOR]', 'sport': 'nba', 'action': '57andp'},
                    {'name': '[COLOR=FF00FF00][ Search Games/Events ][/COLOR]', 'sport': 'search', 'action': 'search'}]
        Index().root_list(root_list)
        
class Index:
    def __init__(self):
        pass

    @staticmethod
    def get_user_input(header, user_input=''):
        k = control.keyboard(user_input, header) ; k.doModal()
        q = k.getText() if k.isConfirmed() else None

        return q
        
    @staticmethod
    def download(url):
        try:
            name = re.search(r"(?:https?://)(?:www\.)?filenurse\.com/download/([a-zA-Z0-9]+)\.html?", url).groups()[0]
            enc_name = name.translate(None, '\/:*?"<>|')
            
            archive_path = os.path.join(tempPath, '%s_archives/' % subreddit)
            if not xbmcvfs.exists(archive_path):
                xbmcvfs.mkdir(archive_path)
                
            archive_dir = os.path.join(archive_path, '%s/' % enc_name)
            if not xbmcvfs.exists(archive_dir):
                xbmcvfs.mkdir(archive_dir)
                
            key_exists = False
            file_edit = False
            if not xbmcvfs.exists('%s.fixed' % archive_dir):
                cookies = client.request(url, output='cookie', close=False)
                result = client.request(url, cookie=cookies)
                zip_id = re.search(r"/files/([a-zA-Z0-9]+)(?:\.zip)", result).groups()[0]
                zip_url = 'http://filenurse.com/files/%s.zip' % zip_id

                import zipfile,StringIO
                headers = {'User-Agent': client.agent(), 'Referer': url, 'Cookie': cookies, 'Host': 'filenurse.com', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8', 'Accept-Encoding': 'gzip, deflate, sdch', 'Accept-Language': 'en-US,en;q=0.8'}
                data = urllib2.Request(zip_url, headers=headers)
                data = urllib2.urlopen(data, timeout=30).read()
                zip_file = zipfile.ZipFile(StringIO.StringIO(data))
                if any(x.endswith('.key') for x in zip_file.namelist()): key_exists = True
                zip_file.extractall(archive_dir)
                zip_file.close()
                file_edit = True
            
            name, url = [], []
            enc_archive_dir = archive_dir.replace("\\", "\\\\")
            files = os.listdir(archive_dir)
            for fname in files:
                if fname.endswith('.m3u8'):
                    name.append(str(fname.replace(".m3u8", "")).encode("utf-8"))
                    m3u8_file = os.path.join(archive_dir, fname)
                    url.append(m3u8_file)
                    
                    if not xbmcvfs.exists('%s.fixed' % archive_dir) and key_exists:
                        try:
                            # Read in the file
                            this_file = xbmcvfs.File(m3u8_file)
                            filedata = this_file.read()
                            # Replace the target string
                            filedata = filedata.replace('URI="', 'URI="%s' % enc_archive_dir)
                            # Write the file out again
                            this_file = xbmcvfs.File(m3u8_file, 'w')
                            this_file.write(filedata)
                            # Close the file
                            this_file.close()
                            file_edit = True
                        except:
                            file_edit = False
                            pass
            
            if not xbmcvfs.exists('%s.fixed' % archive_dir) and file_edit:
                this_file = xbmcvfs.File('%s.fixed' % archive_dir, 'w')
                this_file.close()
            
            if len(name) > 1:
                dialog = xbmcgui.Dialog()
                stream = dialog.select('Choose a stream', name)
                
                if stream == -1:
                    exit()
            else:
                stream = 0
            
            return url[stream]
            
        except Exception as e:
            dialog = xbmcgui.Dialog()
            dialog.notification(subreddit.upper(), str(e).encode("utf-8"), xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        
    @staticmethod
    def root_list(root_list):
        total = len(root_list)
        for i in root_list:
            try:
                name = i['name'].encode("utf-8")
                sport = i['sport']
                logo = Images().logo[sport]
                addonFanart = Images().fanart[sport]
                this_action = i['action']
                u = '%s?action=%s&sport=%s' % (sys.argv[0], this_action, sport)

                item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=logo)
                item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name } )
                item.setProperty("Fanart_Image", addonFanart)
                item.addContextMenuItems([], replaceItems=False)
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)
            except:
                pass
                
    @staticmethod
    def thread_list(thread_list):
        if thread_list is None: return

        total = len(thread_list)
        for i in thread_list:
            try:
                name, url = i['name'], i['url']
                sport = i['sport']
                logo = Images().logo[sport]
                addonFanart = Images().fanart[sport]
                sysname, sysurl = urllib.quote_plus(name), urllib.quote_plus(url)

                u = '%s?action=sources&url=%s&sport=%s&comment=true' % (sys.argv[0], sysurl, sport)

                item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=logo)
                item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name } )
                item.setProperty("Fanart_Image", addonFanart)
                item.addContextMenuItems([], replaceItems=False)
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)
            except:
                pass
                
    @staticmethod
    def source_list(source_list):
        if source_list is None: return
        default_quality = getSetting("default_quality")

        total = len(source_list)
        for i in source_list:
            try:
                name, url, title = i['name'], i['url'], i['title']
                sport = i['sport']
                logo = Images().logo[sport]
                addonFanart = Images().fanart[sport]
                c_menu = []

                sysname, sysurl = urllib.quote_plus(name), urllib.quote_plus(url)
                if 'wake_up_post' in url:
                    sysurl = url.split('_')[-1]
                    comment = i['comment']
                    u = '%s?action=wake&name=%s&url=%s&sport=%s&comment=%s' % (sys.argv[0], sysname, sysurl, sport, comment)
                elif url == '583v7u' or url == '583vc4':
                    u = '%s?action=%s&sport=%s' % (sys.argv[0], url, sport)
                else:
                    u = '%s?action=play&name=%s&url=%s&sport=%s&default_quality=%s' % (sys.argv[0], sysname, sysurl, sport, default_quality)
                    if not "replay" in title.lower():
                        if default_quality == 'false':
                            c_menu.append(('Play Default Quality', 'PlayMedia(%s&default_quality=true)' % u))
                        else:
                            c_menu.append(('Choose Quality', 'PlayMedia(%s&default_quality=false)' % u))

                item = xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=logo)
                item.setInfo( type="Video", infoLabels = { "Label": name, "Title": name } )
                is_folder = False
                if url:
                    if not 'wake_up_post' in url and not url == '583v7u' and not url == '583vc4':
                        item.setProperty("IsPlayable", "true")
                    else:
                        is_folder = True
                item.setProperty("Video", "true")
                item.setProperty("Fanart_Image", addonFanart)
                item.addContextMenuItems(c_menu, replaceItems=True)
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=is_folder)
            except:
                pass
                
class Threads:
    def __init__(self):
        self.list = []

    def get(self, sub):
        self.list = self.thread_list(sub)
        #self.list = cache(self.thread_list, sub)
        Index().thread_list(self.list)
    
    def thread_list(self, sub):
        try:
            r = praw.Reddit(user_agent=userAgent)
            if username and password:
                try:
                    r.login(username, password, disable_warning=True)
                except:
                    dialog = xbmcgui.Dialog()
                    dialog.notification(subreddit.upper(), 'Please make sure reddit login and password are correct', xbmcgui.NOTIFICATION_WARNING, 3000)
                    return
            r.config.api_request_delay = 0
            if sub == subreddit:
                num_results = (25 * (int(getSetting("num_pages"))+1))
                threads = r.get_subreddit(subreddit).get_new(limit=num_results)
            else:
                threads = r.search(sub, subreddit=subreddit, sort='new', syntax=None, period='week')

        except:
            name = '[COLOR red]Servers are too busy, try again later.[/COLOR]'
            name = name.encode('utf-8')
            self.list.append({'name': name, 'url': '', 'title': name, 'sport': 'default'})
            
            return self.list

        filter_threads = ['?', 'request', 'question', 'reminder', '[req]']
        for thread in threads:
            try:
                if not any(filter_thread in thread.title.lower() for filter_thread in filter_threads) and re.match('(.+?streams4all)', str(thread.author)):
                    url = thread.id
                    url = client.replaceHTMLCodes(url)
                    url = url.encode('utf-8')
                    
                    name = thread.title
                    name = re.sub(r'[^\x00-\x7F]+', '', name)
                    title = name.lower()
                    name = client.replaceHTMLCodes(name)
                    name = '[COLOR=FFFFFF00]%s[/COLOR]' % name
                    name = name.encode('utf-8')
                    
                    if 'nfl' in title: sport = 'nfl'
                    elif 'nba' in title: sport = 'nba'
                    elif 'mlb' in title: sport = 'mlb'
                    elif 'nhl' in title: sport = 'nhl'
                    elif 'ncaaf' in title: sport = 'cfb'
                    elif 'nasl' in title or 'soccer' in title or 'mls' in title: sport = 'soccer'
                    elif 'wwe' in title: sport = 'wwe'
                    elif 'ufc' in title or 'mma' in title: sport = 'mma'
                    elif 'boxing' in title: sport = 'boxing'
                    else: sport = 'default'
                    
                    self.list.append({'name': name, 'url': url, 'title': name, 'sport': sport})
            except:
                pass
        
        #print self.list
        if len(self.list)==0: 
            name = '[COLOR red]No games found[/COLOR]'
            name = name.encode('utf-8')
            self.list.append({'name': name, 'url': '', 'title': name, 'sport': 'default'})

        return self.list
        
class Sources:
    def __init__(self):
        self.list = []

    def get(self, url, sport, comment):
        self.list = self.srcs_list(url, sport, comment)
        #self.list = cache(self.srcs_list, url, sport, comment)
        Index().source_list(self.list)
        
    @staticmethod
    def wake(url, sport, comment):
        try:
            if comment == 'true':
                default_comment = getSetting("default_comment")
                use_default = getSetting('use_default')
                if default_comment == '':
                    default_comment = Index().get_user_input('Comment Text', '')
                    if not default_comment:
                        dialog = xbmcgui.Dialog()
                        dialog.notification(subreddit.upper(), 'You must enter a comment', xbmcgui.NOTIFICATION_WARNING, 3000)
                        return
                    else:
                        setSetting(id='default_comment', value=str(default_comment).encode('utf-8'))
                elif use_default == 'false':
                    default_comment = Index().get_user_input('Comment Text', '')
                    if not default_comment:
                        dialog = xbmcgui.Dialog()
                        dialog.notification(subreddit.upper(), 'You must enter a comment', xbmcgui.NOTIFICATION_WARNING, 3000)
                        return
                r = praw.Reddit(user_agent=userAgent)
                if username and password:
                    try:
                        r.login(username, password, disable_warning=True)
                    except:
                        dialog = xbmcgui.Dialog()
                        dialog.notification(subreddit.upper(), 'Please make sure reddit login and password are correct', xbmcgui.NOTIFICATION_WARNING, 3000)
                        return
                r.config.api_request_delay = 0
                submission = r.get_submission(submission_id=url)
                submission.add_comment(str(default_comment + ' [v' + addonVersion + ']').encode('utf-8'))
                message = 'Making top level comment.'
            else: message = 'Checking for stream.'
            p_dialog = xbmcgui.DialogProgress()
            p_dialog.create('No Streams for You', message)
            sleep_time = 30
            for i in range(0, sleep_time):
                percent = int( ( float(i) / float(sleep_time) ) * 100)
                message2 = "Reloading thread in %s seconds..." % (sleep_time-i)
                p_dialog.update(percent, "", message2, "")
                xbmc.sleep(1000)
                if p_dialog.iscanceled():
                    break
            p_dialog.close()
            xbmc.executebuiltin('XBMC.Container.Refresh(''%s?action=sources&url=%s&sport=%s&comment=false'')' % (sys.argv[0], url, sport))
            
            return
            
        except:
            dialog = xbmcgui.Dialog()
            dialog.notification(subreddit.upper(), 'Unable to add comment', xbmcgui.NOTIFICATION_WARNING, 3000)
            return

    def srcs_list(self, url, sport, comment):
        url_pattern = r"(?i)\b((?:https?://|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:'\".,<>?«»“”‘’*]))"
        try:
            r = praw.Reddit(user_agent=userAgent)
            if username and password:
                try:
                    r.login(username, password, disable_warning=True)
                except:
                    dialog = xbmcgui.Dialog()
                    dialog.notification(subreddit.upper(), 'Please make sure reddit login and password are correct', xbmcgui.NOTIFICATION_WARNING, 3000)
                    return
            r.config.api_request_delay = 0
            flat_comments = []
            if 'wiki' in url:
                wiki = url.split("/")[1]
                submission = r.get_wiki_page(subreddit, wiki)
            else:
                submission = r.get_submission(submission_id=url)
                if getSetting("show_comments") == 'true': flat_comments = praw.helpers.flatten_tree(submission.comments)
            
        except:
            name = '[COLOR red]Servers are too busy, try again later.[/COLOR]'
            name = name.encode('utf-8')
            self.list.append({'name': name, 'url': '', 'title': name, 'sport': 'default'})
            
            return self.list

        try:
            if 'wiki' in url:
                selftext = submission.content_md
                selftitle = wiki
            else: 
                selftext = submission.selftext
                selftitle = submission.title
                
            selftext = re.sub(r'[^\x00-\x7F]+', '', selftext)
            selftext = client.replaceHTMLCodes(selftext)
            selftext = selftext.encode('utf-8')
            #print selftext
            
            selftitle = re.sub(r'[^\x00-\x7F]+', '', selftitle)
            selftitle = client.replaceHTMLCodes(selftitle)
            selftitle = selftitle.encode('utf-8')
            #print selftitle
            
            self_text_lower = selftext.lower()
            statuses = ['game is over', 'event is over', 'game is final', 'no redzone, sorry', 'pending', 'filenurse.com/download']
            paused = ['please make a top level post to wake up', 'please make a top level comment', 'please comment to wake up']
            self_text_lines = selftext.split('\n')
            location = ['Unknown']
            for line in self_text_lines:
                if line:
                    self_text_line = line.strip()
                    break
            if any(status in self_text_lower for status in statuses):
                try:
                    zip_id = re.search(r"(?:https?://)(?:www\.)?filenurse\.com/download/([a-zA-Z0-9]+)\.html?", selftext).groups()[0]
                    if zip_id:
                        zip_loc = 'http://filenurse.com/download/%s.html' % zip_id
                        if 'replay streams' in self_text_lower:
                            streamType = ' Replay'
                            for line in self_text_lines:
                                if 'is over' in line.lower():
                                    self_text_line = line.strip()
                                    break
                        else:
                            streamType = ''
                            for line in self_text_lines:
                                if 'this m3u8' in line.lower():
                                    self_text_line = line.strip()
                                    break
                        self.list.append({'name': selftitle, 'url': zip_loc, 'title': '[COLOR=FF00FF00]Play%s Stream[/COLOR]' % streamType, 'sport': sport})
                except:
                    pass
                self.list.append({'name': selftitle, 'url': '', 'title': '[COLOR=FFFFA500]%s[/COLOR]' % self_text_line, 'sport': sport})
            elif any(pause in self_text_lower for pause in paused):
                if comment == 'true':
                    self.list.append({'name': selftitle, 'url': 'wake_up_post_%s' % url, 'title': '[COLOR=FF00FF00]Add comment to wake up post and check for stream[/COLOR]', 'sport': sport, 'comment': 'true'})
                    #self.list.append({'name': selftitle, 'url': '', 'title': '[COLOR=FFFFA500]%s[/COLOR]' % self_text_line, 'sport': sport})
                else:
                    self.list.append({'name': selftitle, 'url': 'wake_up_post_%s' % url, 'title': '[COLOR=FF00FF00]Check for stream again without making comment[/COLOR]', 'sport': sport, 'comment': 'false'})
            else:
                if sport == 'mlb' and not url == '48idsl':
                    location = re.findall(r"(?:([a-zA-Z]+) Stream)", selftext)
                    m3u8 = re.findall(r"To use kodi, make your \.strm file with this:\s+(https?://.+?)\s", selftext)
                    #location.extend(['with blackout fix for %s' % x for x in location])
                    #m3u8.extend(['%s&X-Forwarded-For=31.173.74.73' % x for x in m3u8])
                elif url == '583v7u':
                    location = ['ESPN U', 'ESPN', 'ESPN 2', 'ESPNews', 'Longhorn Network', 'ESPN Goal Line, Buzzer Beater, Bases Loaded']
                    m3u8 = re.findall(r"Kodi make a \.strm file with this:\s+(https?://.+?)\s", selftext)
                elif url == '4vysxl':
                    m3u8 = re.search(r"\*\*Kodi \(strm file\)\*\*\s+(https?://.+)\s*", selftext).groups()[0]
                elif 'clearstreams' in url or url == '3r6jhz':
                    streams = re.findall(r"(.+?):\s*(https?://\S+)", selftext)
                    location, m3u8 = [], []
                    for stream in streams:
                        location.append(stream[0])
                        url = stream[1]
                        m3u8.append(url)
                elif sport == 'nhl':
                    location = re.findall(r"(?:\*{0,2}([A-Z]+)\*{0,2}:)", selftext)
                    if location:
                        m3u8 = re.findall(r"Kodi users make a \.strm file with this:\s+(https?://.+?)\s", selftext)
                        if getSetting("select_cookie") == 'true':
                            cookies = re.findall(r'(?i)\[(cookie?.+?|.+?cookie?)\]\((.+?)\)', selftext)
                            if cookies:
                                cookie = [x[0] for x in cookies]
                                dialog = xbmcgui.Dialog()
                                selected = dialog.select('Choose your bake cookie', cookie)
                                if selected != -1:
                                    import json
                                    result = client.request(cookies[selected][1], timeout='10')
                                    result = json.loads(result)
                                    try:
                                        mediaAuth = result['session_info']['sessionAttributes'][0]['attributeValue']
                                        #mediaAuth = re.search(r'\{\"attributeName\":\"mediaAuth\",\"attributeValue\":\"(.+?)\"\}', result).groups()[0]
                                        m3u8 = ['%s|Cookie=mediaAuth=%s' % (x.split("|")[0], urllib.quote_plus(mediaAuth)) for x in m3u8]
                                    except:
                                        dialog = xbmcgui.Dialog()
                                        dialog.notification(subreddit.upper(), 'mediaAuth not found go back try another bake cookie', xbmcgui.NOTIFICATION_WARNING, 6000)
                    else:
                        try:
                            m3u8 = re.findall(url_pattern, selftext)[0][0]
                        except:
                            m3u8 = False
                elif sport == 'nba':
                    streams = re.findall(r'([a-zA-Z]+):\s*(http.*)', selftext)
                    if streams:
                        location, m3u8 = [], []
                        for stream in streams:
                            location.append(stream[0])
                            m3u8.append(stream[1])
                    else:
                        try:
                            m3u8 = re.findall(url_pattern, selftext)[0][0]
                        except:
                            m3u8 = False
                else:
                    try:
                        m3u8 = re.findall(url_pattern, selftext)[0][0]
                    except:
                        m3u8 = False
                
                if m3u8:
                    if not isinstance(m3u8, str):
                        i = 0
                        b = len(location)
                        # noinspection PyTypeChecker
                        for url in m3u8:
                            self.list.append({'name': location[i], 'url': url.strip(), 'title': '[COLOR=FF00FF00]Play %s Stream[/COLOR]' % location[i], 'sport': sport})
                            if b > 1: i+=1
                    else:
                        self.list.append({'name': selftitle, 'url': m3u8.strip(), 'title': '[COLOR=FF00FF00]Play Stream[/COLOR]', 'sport': sport})
                else:
                    #self_text_line = selftext.split('\n')[0]
                    if 'This game is on' in self_text_line:
                        if 'This game is on ESPN' in self_text_line or 'This game is on Longhorn' in self_text_line:
                            self.list.append({'name': selftitle, 'url': '583v7u', 'title': '[COLOR=FF00FF00]Go to ESPN channels[/COLOR]', 'sport': sport})
                        if 'This game is on SEC' in self_text_line:
                            self.list.append({'name': selftitle, 'url': '583vc4', 'title': '[COLOR=FF00FF00]Go to SEC Network[/COLOR]', 'sport': sport})
                    self.list.append({'name': selftitle, 'url': '', 'title': '[COLOR=FFFFA500]%s[/COLOR]' % self_text_line, 'sport': sport})
                
        except Exception as e:
            print "Exception:", e
            pass
        
        if len(self.list)==0: 
            name = '[COLOR red]Unable to locate stream[/COLOR]'
            name = name.encode('utf-8')
            self.list.append({'name': name, 'url': '', 'title': name, 'sport': sport})
        
        try:
            if not 'wiki' in url:
                for line in self_text_lines:
                    if 'if you need a topic' in line.lower():
                        self_text_line = re.search(r'If you need a topic for your top level post:\s*\*\*(.+?)\*\*', line).groups()[0]
                        if not self_text_line: self_text_line = line.replace("**", "")
                        self_text_line = self_text_line.strip()
                        self.list.append({'name': selftitle, 'url': '', 'title': '[COLOR=FFFFA500]%s[/COLOR]' % self_text_line, 'sport': sport})
                        break
                if len(flat_comments) > 0:
                    i = 0
                    num_comments = getSetting("num_comments")
                    self.list.append({'name': '[COLOR=FFFFFF00]User Submitted Comments:[/COLOR]', 'url': '', 'title': '[COLOR=FFFFFF00]User  Submitted Comments:[/COLOR]', 'sport': sport})
                    for user_comment in flat_comments:
                        user_comment = re.sub(r'[^\x00-\x7F]+', '', user_comment.body)
                        user_comment = user_comment.split("\n")[0]
                        user_comment = client.replaceHTMLCodes(user_comment)
                        user_comment = user_comment.encode('utf-8')
                        user_comment = user_comment.strip()
                        if user_comment:
                            self.list.append({'name': user_comment, 'url': '', 'title': user_comment, 'sport': sport})
                            i += 1
                        if i == int(num_comments): break
        except:
            pass
                
        return self.list
        


Main()